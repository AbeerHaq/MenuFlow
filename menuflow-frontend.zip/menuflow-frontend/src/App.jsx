import { Routes, Route, Navigate } from 'react-router-dom'
import ProtectedRoute from './components/ProtectedRoute'
import MenuPage from './pages/MenuPage'
import OrderStatusPage from './pages/OrderStatusPage'
import LiveOrdersPage from './pages/LiveOrdersPage'
import AdminLogin from './pages/admin/AdminLogin'
import AdminLayout from './pages/admin/AdminLayout'
import RestaurantsPage from './pages/admin/RestaurantsPage'
import AnalyticsPage from './pages/admin/AnalyticsPage'

export default function App() {
  return (
    <Routes>
      {/* Customer (public) */}
      <Route path="/r/:slug/t/:token" element={<MenuPage />} />
      <Route path="/order/:orderId" element={<OrderStatusPage />} />

      {/* Owner — Live Orders. Abeer's dashboard layout should wrap this route (sidebar + Outlet). */}
      <Route path="/dashboard/orders" element={<ProtectedRoute role="owner"><LiveOrdersPage /></ProtectedRoute>} />

      {/* Admin */}
      <Route path="/admin/login" element={<AdminLogin />} />
      <Route path="/admin" element={<ProtectedRoute role="admin"><AdminLayout /></ProtectedRoute>}>
        <Route index element={<Navigate to="restaurants" replace />} />
        <Route path="restaurants" element={<RestaurantsPage />} />
        <Route path="analytics" element={<AnalyticsPage />} />
      </Route>

      <Route path="*" element={<div className="center"><h2>Page not found</h2></div>} />
    </Routes>
  )
}
