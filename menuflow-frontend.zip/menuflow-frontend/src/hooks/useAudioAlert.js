import { useRef, useState, useCallback } from 'react'
// Browsers block audio until a user gesture, so `enable()` must be called from a click.
export default function useAudioAlert() {
  const ctx = useRef(null)
  const [enabled, setEnabled] = useState(false)
  const beep = useCallback(() => {
    const c = ctx.current; if (!c) return
    ;[0, 0.22].forEach((d, i) => {
      const o = c.createOscillator(), g = c.createGain()
      o.frequency.value = i ? 1040 : 784; o.type = 'sine'
      g.gain.setValueAtTime(0.0001, c.currentTime + d)
      g.gain.exponentialRampToValueAtTime(0.4, c.currentTime + d + 0.02)
      g.gain.exponentialRampToValueAtTime(0.0001, c.currentTime + d + 0.3)
      o.connect(g).connect(c.destination); o.start(c.currentTime + d); o.stop(c.currentTime + d + 0.32)
    })
  }, [])
  const enable = useCallback(() => {
    ctx.current = ctx.current || new (window.AudioContext || window.webkitAudioContext)()
    ctx.current.resume(); setEnabled(true); beep()
  }, [beep])
  return { enabled, enable, play: beep }
}
