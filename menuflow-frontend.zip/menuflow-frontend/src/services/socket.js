import { io } from 'socket.io-client'
const URL = import.meta.env.VITE_SOCKET_URL || 'http://localhost:5000'
// token => owner handshake (JWT); no token => anonymous customer
export const createSocket = token => io(URL, { auth: token ? { token } : {}, autoConnect: true })
