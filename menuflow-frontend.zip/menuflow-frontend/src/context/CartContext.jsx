import { createContext, useContext, useEffect, useState } from 'react'
const Ctx = createContext(null)
export const useCart = () => useContext(Ctx)
// Cart is scoped to one restaurant + table and persisted on the device.
export function CartProvider({ scope, children }) {
  const key = `mf_cart_${scope}`
  const [items, setItems] = useState(() => { try { return JSON.parse(localStorage.getItem(key)) || [] } catch { return [] } })
  useEffect(() => localStorage.setItem(key, JSON.stringify(items)), [items, key])
  const add = it => setItems(p => p.some(x => x._id === it._id)
    ? p.map(x => x._id === it._id ? { ...x, qty: x.qty + 1 } : x)
    : [...p, { _id: it._id, name: it.name, price: it.price, qty: 1 }])
  const setQty = (id, q) => setItems(p => q <= 0 ? p.filter(x => x._id !== id) : p.map(x => x._id === id ? { ...x, qty: q } : x))
  const clear = () => setItems([])
  const count = items.reduce((s, x) => s + x.qty, 0)
  const total = items.reduce((s, x) => s + x.qty * x.price, 0)
  return <Ctx.Provider value={{ items, add, setQty, clear, count, total }}>{children}</Ctx.Provider>
}
