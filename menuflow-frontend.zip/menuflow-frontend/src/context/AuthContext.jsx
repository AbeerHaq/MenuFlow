import { createContext, useContext, useEffect, useState } from 'react'
import api from '../services/api'
const Ctx = createContext(null)
export const useAuth = () => useContext(Ctx)
export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)
  const [token, setToken] = useState(localStorage.getItem('mf_token'))
  const [loading, setLoading] = useState(!!localStorage.getItem('mf_token'))
  useEffect(() => {
    if (!token) return setLoading(false)
    api.get('/auth/me').then(r => setUser(r.data.user || r.data)).catch(logout).finally(() => setLoading(false))
  }, [])
  const login = async (email, password) => {
    const { data } = await api.post('/auth/login', { email, password })
    localStorage.setItem('mf_token', data.token); setToken(data.token); setUser(data.user); return data.user
  }
  function logout() { localStorage.removeItem('mf_token'); setToken(null); setUser(null) }
  return <Ctx.Provider value={{ user, token, loading, login, logout }}>{children}</Ctx.Provider>
}
