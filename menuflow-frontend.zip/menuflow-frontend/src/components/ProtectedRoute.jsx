import { Navigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
export default function ProtectedRoute({ role, children }) {
  const { user, token, loading } = useAuth()
  if (loading) return <div className="center">Loading…</div>
  if (!token || !user) return <Navigate to={role === 'admin' ? '/admin/login' : '/login'} replace />
  if (role && user.role !== role) return <Navigate to="/" replace />
  return children
}
