export const STEPS = ['PENDING', 'ACCEPTED', 'PREPARING', 'READY', 'COMPLETED']
const label = s => s[0] + s.slice(1).toLowerCase()
export default function StatusStepper({ status }) {
  if (status === 'REJECTED') return <div className="banner bad">The restaurant couldn't take this order. Please ask your server for help.</div>
  const idx = STEPS.indexOf(status)
  return (
    <ol className="stepper">
      {STEPS.map((s, i) => (
        <li key={s} className={i < idx ? 'done' : i === idx ? 'now' : ''}><span className="dot" /><span>{label(s)}</span></li>
      ))}
    </ol>
  )
}
export const money = n => Number(n || 0).toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 })
