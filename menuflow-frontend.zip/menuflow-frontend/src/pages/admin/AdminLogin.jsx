import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'
import { errMsg } from '../../services/api'
export default function AdminLogin() {
  const { login, logout } = useAuth(); const nav = useNavigate()
  const [f, setF] = useState({ email: '', password: '' }); const [err, setErr] = useState(''); const [busy, setBusy] = useState(false)
  const submit = async e => {
    e.preventDefault(); setBusy(true); setErr('')
    try { const u = await login(f.email, f.password); if (u.role !== 'admin') { logout(); throw new Error('This account is not an admin account.') } nav('/admin/restaurants') }
    catch (x) { setErr(errMsg(x)); setBusy(false) }
  }
  return (
    <form className="center narrow loginform" onSubmit={submit}>
      <h1>Admin sign in</h1>
      <input type="email" placeholder="Email" required value={f.email} onChange={e => setF({ ...f, email: e.target.value })} />
      <input type="password" placeholder="Password" required value={f.password} onChange={e => setF({ ...f, password: e.target.value })} />
      {err && <div className="banner bad">{err}</div>}
      <button className="btn" disabled={busy}>{busy ? 'Signing in…' : 'Sign in'}</button>
    </form>)
}
