import { useEffect, useState } from 'react'
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, ResponsiveContainer } from 'recharts'
import api, { errMsg } from '../../services/api'
import { money } from '../../components/StatusStepper'
const iso = d => d.toISOString().slice(0, 10)
export default function AnalyticsPage() {
  const [from, setFrom] = useState(iso(new Date(Date.now() - 29 * 864e5))), [to, setTo] = useState(iso(new Date()))
  const [d, setD] = useState(null), [err, setErr] = useState('')
  useEffect(() => { setErr(''); api.get('/admin/analytics/revenue', { params: { from, to } }).then(r => setD(r.data)).catch(e => setErr(errMsg(e))) }, [from, to])
  const t = d?.totals || {}
  const top = [...(d?.byRestaurant || [])].sort((a, b) => b.revenue - a.revenue).slice(0, 8)
  return (
    <>
      <div className="row top"><h1>Revenue</h1>
        <div className="filters"><input type="date" value={from} max={to} onChange={e => setFrom(e.target.value)} /><input type="date" value={to} min={from} onChange={e => setTo(e.target.value)} /></div></div>
      <p className="muted">Counts completed orders only.</p>
      {err && <div className="banner bad">{err}</div>}
      <div className="stats">
        <div className="stat"><span>Total revenue</span><strong>{money(t.revenue)}</strong></div>
        <div className="stat"><span>Completed orders</span><strong>{t.orders ?? 0}</strong></div>
        <div className="stat"><span>Active restaurants</span><strong>{t.restaurants ?? 0}</strong></div>
      </div>
      <div className="card chart"><h3>Revenue over time</h3>
        <ResponsiveContainer width="100%" height={260}><LineChart data={d?.byDate || []}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e3e0d6" /><XAxis dataKey="date" fontSize={12} /><YAxis fontSize={12} /><Tooltip />
          <Line type="monotone" dataKey="revenue" stroke="#0f5c4d" strokeWidth={2.5} dot={false} /></LineChart></ResponsiveContainer></div>
      <div className="card chart"><h3>Top restaurants</h3>
        <ResponsiveContainer width="100%" height={260}><BarChart data={top}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e3e0d6" /><XAxis dataKey="name" fontSize={12} /><YAxis fontSize={12} /><Tooltip />
          <Bar dataKey="revenue" fill="#e0a526" radius={[4, 4, 0, 0]} /></BarChart></ResponsiveContainer></div>
    </>)
}
