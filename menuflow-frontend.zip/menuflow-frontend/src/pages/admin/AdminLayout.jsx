import { NavLink, Outlet, useNavigate } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'
export default function AdminLayout() {
  const { logout } = useAuth(); const nav = useNavigate()
  return (
    <div className="admin">
      <aside className="side">
        <h2>MenuFlow</h2>
        <NavLink to="restaurants">Restaurants</NavLink>
        <NavLink to="analytics">Revenue</NavLink>
        <button className="link" onClick={() => { logout(); nav('/admin/login') }}>Sign out</button>
      </aside>
      <section className="content"><Outlet /></section>
    </div>)
}
