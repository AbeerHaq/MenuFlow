import { useEffect, useMemo, useState } from 'react'
import api, { errMsg } from '../../services/api'
import { money } from '../../components/StatusStepper'
export default function RestaurantsPage() {
  const [list, setList] = useState([]), [q, setQ] = useState(''), [status, setStatus] = useState('all')
  const [confirm, setConfirm] = useState(null), [err, setErr] = useState(''), [loading, setLoading] = useState(true)
  const load = () => api.get('/admin/restaurants').then(r => setList(r.data.restaurants || r.data)).catch(e => setErr(errMsg(e))).finally(() => setLoading(false))
  useEffect(() => { load() }, [])
  const rows = useMemo(() => list.filter(r =>
    (status === 'all' || r.status === status) &&
    `${r.name} ${r.owner?.name || ''} ${r.owner?.email || ''}`.toLowerCase().includes(q.toLowerCase())), [list, q, status])
  const toggle = async r => {
    try { await api.patch(`/admin/restaurants/${r._id}/status`, { status: r.status === 'active' ? 'suspended' : 'active' }); load() }
    catch (e) { setErr(errMsg(e)) }
  }
  const del = async () => {
    try { await api.delete(`/admin/restaurants/${confirm._id}`); setConfirm(null); load() }
    catch (e) { setErr(errMsg(e)); setConfirm(null) }
  }
  return (
    <>
      <h1>Restaurants</h1>
      <div className="filters">
        <input placeholder="Search by restaurant or owner" value={q} onChange={e => setQ(e.target.value)} />
        <select value={status} onChange={e => setStatus(e.target.value)}>
          <option value="all">All statuses</option><option value="active">Active</option><option value="suspended">Suspended</option>
        </select>
      </div>
      {err && <div className="banner bad" onClick={() => setErr('')}>{err}</div>}
      <div className="tablewrap"><table>
        <thead><tr><th>Restaurant</th><th>Owner</th><th>Status</th><th>Joined</th><th>Orders</th><th>Revenue</th><th></th></tr></thead>
        <tbody>{rows.map(r => (
          <tr key={r._id}>
            <td><strong>{r.name}</strong></td><td>{r.owner?.name}<div className="muted small">{r.owner?.email}</div></td>
            <td><span className={`pill ${r.status === 'active' ? 'on' : 'off'}`}>{r.status === 'active' ? 'Active' : 'Suspended'}</span></td>
            <td>{r.createdAt ? new Date(r.createdAt).toLocaleDateString() : '–'}</td>
            <td>{r.totalOrders ?? 0}</td><td>{money(r.totalRevenue)}</td>
            <td className="actions">
              <button className="btn sm ghost" onClick={() => toggle(r)}>{r.status === 'active' ? 'Suspend' : 'Reactivate'}</button>
              <button className="btn sm danger" onClick={() => setConfirm(r)}>Delete</button>
            </td>
          </tr>))}
          {!rows.length && <tr><td colSpan="7" className="center muted">{loading ? 'Loading…' : 'No restaurants match.'}</td></tr>}
        </tbody></table></div>
      {confirm && (
        <div className="overlay" onClick={() => setConfirm(null)}><div className="modal" onClick={e => e.stopPropagation()}>
          <h2>Delete {confirm.name}?</h2>
          <p className="muted">The restaurant will be removed from the platform. Its past revenue stays in your analytics.</p>
          <div className="actions"><button className="btn ghost" onClick={() => setConfirm(null)}>Keep restaurant</button><button className="btn danger" onClick={del}>Delete restaurant</button></div>
        </div></div>)}
    </>)
}
