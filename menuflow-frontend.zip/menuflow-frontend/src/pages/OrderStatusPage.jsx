import { useEffect, useRef, useState } from 'react'
import { useParams } from 'react-router-dom'
import api, { errMsg } from '../services/api'
import { createSocket } from '../services/socket'
import StatusStepper, { money } from '../components/StatusStepper'

export default function OrderStatusPage() {
  const { orderId } = useParams()
  const [order, setOrder] = useState(null)
  const [error, setError] = useState('')
  const [live, setLive] = useState(false)

  useEffect(() => {
    const load = () => api.get(`/public/orders/${orderId}`).then(r => setOrder(r.data.order || r.data)).catch(e => setError(errMsg(e)))
    load()
    const s = createSocket()
    s.on('connect', () => { setLive(true); s.emit('join:order', orderId); load() }) // re-fetch on reconnect
    s.on('disconnect', () => setLive(false))
    s.on('order:updated', o => { if ((o._id || o.orderId) === orderId) setOrder(p => ({ ...p, ...o })) })
    return () => s.disconnect()
  }, [orderId])

  if (error) return <div className="center narrow"><h2>We couldn't find this order</h2><p className="muted">{error}</p></div>
  if (!order) return <div className="center">Loading order…</div>

  const num = order.orderNumber || JSON.parse(sessionStorage.getItem(`mf_order_${orderId}`) || '{}').orderNumber
  const msg = {
    PENDING: 'Waiting for the restaurant to confirm.', ACCEPTED: 'Confirmed. The kitchen will start soon.',
    PREPARING: 'Your food is being prepared.', READY: 'Ready! Your server is bringing it over.',
    COMPLETED: 'Enjoy your meal.', REJECTED: ''
  }[order.status]

  return (
    <div className="customer status">
      <header className="hero"><div><p>Order</p><h1>#{num || orderId.slice(-5)}</h1></div>
        <span className={`pill ${live ? 'on' : ''}`}>{live ? 'Live' : 'Reconnecting…'}</span></header>
      <main>
        <StatusStepper status={order.status} />
        {msg && <p className="statusmsg">{msg}</p>}
        {order.items?.length > 0 && (
          <div className="card">
            {order.items.map((i, k) => <div key={k} className="row"><span>{i.quantity} × {i.nameSnapshot || i.name}</span><span>{money(i.priceSnapshot * i.quantity)}</span></div>)}
            {order.note && <p className="muted small">Note: {order.note}</p>}
            <div className="row total"><span>Total</span><strong>{money(order.totalAmount)}</strong></div>
          </div>)}
      </main>
    </div>)
}
