import { useCallback, useEffect, useRef, useState } from 'react'
import api, { errMsg } from '../services/api'
import { createSocket } from '../services/socket'
import { useAuth } from '../context/AuthContext'
import useAudioAlert from '../hooks/useAudioAlert'
import { money } from '../components/StatusStepper'

const COLS = ['PENDING', 'ACCEPTED', 'PREPARING', 'READY']
// Only valid next actions are offered (server enforces the same rules).
const NEXT = {
  PENDING: [['ACCEPTED', 'Accept'], ['REJECTED', 'Reject']],
  ACCEPTED: [['PREPARING', 'Start preparing']],
  PREPARING: [['READY', 'Mark ready']],
  READY: [['COMPLETED', 'Complete']]
}
const ago = d => { const m = Math.max(0, Math.round((Date.now() - new Date(d)) / 60000)); return m < 1 ? 'just now' : `${m} min ago` }

export default function LiveOrdersPage() {
  const { token, user } = useAuth()
  const [orders, setOrders] = useState([])
  const [toast, setToast] = useState(null)
  const [online, setOnline] = useState(false)
  const [err, setErr] = useState('')
  const audio = useAudioAlert()
  const playRef = useRef(audio.play); playRef.current = audio.play
  const enabledRef = useRef(false); enabledRef.current = audio.enabled

  const fetchOrders = useCallback(() =>
    api.get('/owner/orders', { params: { status: COLS.join(',') } })
      .then(r => setOrders(r.data.orders || r.data)).catch(e => setErr(errMsg(e))), [])

  useEffect(() => {
    fetchOrders()
    const s = createSocket(token)
    const rid = user?.restaurant?._id || user?.restaurant
    s.on('connect', () => { setOnline(true); s.emit('join:restaurant', rid); fetchOrders() }) // recover missed orders
    s.on('disconnect', () => setOnline(false))
    s.on('order:new', o => {
      setOrders(p => p.some(x => x._id === o._id) ? p : [o, ...p])
      setToast(`New order · Table ${o.table?.tableNumber ?? ''}`.trim()); setTimeout(() => setToast(null), 5000)
      if (enabledRef.current) playRef.current()
    })
    s.on('order:updated', o => setOrders(p => p.some(x => x._id === o._id) ? p.map(x => x._id === o._id ? { ...x, ...o } : x) : [o, ...p]))
    return () => s.disconnect()
  }, [token])

  const move = async (o, status) => {
    const prev = orders
    setOrders(p => p.map(x => x._id === o._id ? { ...x, status } : x)) // optimistic
    try { await api.patch(`/owner/orders/${o._id}/status`, { status }) }
    catch (e) { setOrders(prev); setErr(errMsg(e)) } // roll back if server rejects
  }
  const visible = orders.filter(o => COLS.includes(o.status))

  return (
    <div className="dash">
      <div className="row top">
        <div><h1>Live orders</h1><span className={`pill ${online ? 'on' : ''}`}>{online ? 'Connected' : 'Reconnecting…'}</span></div>
        {audio.enabled ? <span className="muted">Sound alerts on</span> : <button className="btn sm" onClick={audio.enable}>Enable sound alerts</button>}
      </div>
      {err && <div className="banner bad" onClick={() => setErr('')}>{err}</div>}
      {toast && <div className="toast">{toast}</div>}
      <div className="board">
        {COLS.map(c => {
          const list = visible.filter(o => o.status === c).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
          return (
            <section key={c} className="col">
              <h2>{c[0] + c.slice(1).toLowerCase()} <span className="count">{list.length}</span></h2>
              {list.map(o => (
                <article key={o._id} className="ocard">
                  <div className="row"><strong>Table {o.table?.tableNumber ?? '–'}</strong><span className="muted small">#{o.orderNumber} · {ago(o.createdAt)}</span></div>
                  {o.customerName && <div className="muted small">{o.customerName}</div>}
                  <ul>{o.items?.map((i, k) => <li key={k}>{i.quantity} × {i.nameSnapshot || i.name}</li>)}</ul>
                  {o.note && <div className="note">“{o.note}”</div>}
                  <div className="row total"><span>Total</span><strong>{money(o.totalAmount)}</strong></div>
                  <div className="actions">{NEXT[o.status].map(([s, l]) =>
                    <button key={s} className={`btn sm ${s === 'REJECTED' ? 'ghost' : ''}`} onClick={() => move(o, s)}>{l}</button>)}</div>
                </article>))}
              {!list.length && <p className="muted small empty">No {c.toLowerCase()} orders</p>}
            </section>)
        })}
      </div>
    </div>)
}
