import { useEffect, useMemo, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import api, { errMsg } from '../services/api'
import { CartProvider, useCart } from '../context/CartContext'
import { money } from '../components/StatusStepper'

export default function MenuPage() {
  const { slug, token } = useParams()
  return <CartProvider scope={`${slug}_${token}`}><Menu slug={slug} token={token} /></CartProvider>
}

function Menu({ slug, token }) {
  const [data, setData] = useState(null)
  const [error, setError] = useState('')
  const [active, setActive] = useState(null)
  const [open, setOpen] = useState(false)
  const { add, count, total, items } = useCart()

  useEffect(() => {
    api.get(`/public/menu/${slug}/${token}`)
      .then(r => { setData(r.data); setActive(null) })
      .catch(e => setError(e?.response?.status ? 'unavailable' : errMsg(e)))
  }, [slug, token])

  const categories = useMemo(() => {
    if (!data) return []
    const cats = data.categories || []
    const flat = data.items || data.menuItems || []
    return cats.map(c => ({
      ...c,
      items: c.items || flat.filter(i => (i.category?._id || i.category) === c._id)
    })).filter(c => c.items.length)
  }, [data])

  if (error) return (
    <div className="center narrow">
      <h2>This menu isn't available</h2>
      <p className="muted">The QR code may be out of date, or the restaurant has paused ordering. Please ask a staff member for help.</p>
    </div>)
  if (!data) return <div className="center">Loading menu…</div>

  const r = data.restaurant || {}, table = data.table || {}
  const shown = active ? categories.filter(c => c._id === active) : categories

  return (
    <div className="customer">
      <header className="hero">
        {r.logoUrl && <img src={r.logoUrl} alt="" className="logo" />}
        <div><h1>{r.name}</h1><p>Table {table.tableNumber}{r.address ? ` · ${r.address}` : ''}</p></div>
      </header>
      <nav className="tabs">
        <button className={!active ? 'on' : ''} onClick={() => setActive(null)}>All</button>
        {categories.map(c => <button key={c._id} className={active === c._id ? 'on' : ''} onClick={() => setActive(c._id)}>{c.name}</button>)}
      </nav>
      <main>
        {shown.map(c => (
          <section key={c._id}>
            <h2>{c.name}</h2>
            {c.items.map(it => {
              const inCart = items.find(x => x._id === it._id)
              return (
                <article key={it._id} className={`item ${it.isAvailable === false ? 'off' : ''}`}>
                  {it.imageUrl && <img src={it.imageUrl} alt={it.name} loading="lazy" />}
                  <div className="info">
                    <h3>{it.name}</h3>
                    {it.description && <p className="muted">{it.description}</p>}
                    <div className="row"><strong>{money(it.price)}</strong>
                      {it.isAvailable === false ? <span className="tag">Sold out</span>
                        : <button className="btn sm" onClick={() => add(it)}>{inCart ? `Add another (${inCart.qty})` : 'Add'}</button>}
                    </div>
                  </div>
                </article>)
            })}
          </section>))}
        {!categories.length && <p className="center muted">The menu is empty right now.</p>}
      </main>
      {count > 0 && <button className="cartbar" onClick={() => setOpen(true)}><span>{count} item{count > 1 ? 's' : ''}</span><span>View cart · {money(total)}</span></button>}
      {open && <CartDrawer token={token} slug={slug} onClose={() => setOpen(false)} />}
    </div>
  )
}

function CartDrawer({ token, slug, onClose }) {
  const { items, setQty, clear, total } = useCart()
  const [name, setName] = useState(''), [note, setNote] = useState('')
  const [busy, setBusy] = useState(false), [err, setErr] = useState('')
  const nav = useNavigate()

  const place = async () => {
    setBusy(true); setErr('')
    try {
      // Only ids + quantities are sent; the server re-reads prices and computes the total.
      const { data } = await api.post('/public/orders', {
        slug, token, customerName: name.trim() || undefined, note: note.trim() || undefined,
        items: items.map(i => ({ menuItem: i._id, quantity: i.qty }))
      })
      const id = data.orderId || data._id || data.order?._id
      sessionStorage.setItem(`mf_order_${id}`, JSON.stringify({ orderNumber: data.orderNumber || data.order?.orderNumber }))
      clear(); nav(`/order/${id}`)
    } catch (e) { setErr(errMsg(e)); setBusy(false) }
  }

  return (
    <div className="overlay" onClick={onClose}>
      <aside className="drawer" onClick={e => e.stopPropagation()}>
        <div className="row"><h2>Your order</h2><button className="link" onClick={onClose}>Close</button></div>
        {items.map(i => (
          <div key={i._id} className="line">
            <div><strong>{i.name}</strong><div className="muted">{money(i.price)} each</div></div>
            <div className="qty">
              <button aria-label="Remove one" onClick={() => setQty(i._id, i.qty - 1)}>−</button>
              <span>{i.qty}</span>
              <button aria-label="Add one" onClick={() => setQty(i._id, i.qty + 1)}>+</button>
            </div>
          </div>))}
        <input placeholder="Your name (optional)" value={name} maxLength={40} onChange={e => setName(e.target.value)} />
        <textarea placeholder="Note for the kitchen, e.g. no onions" value={note} maxLength={200} rows={2} onChange={e => setNote(e.target.value)} />
        <div className="row total"><span>Total</span><strong>{money(total)}</strong></div>
        <p className="muted small">You'll pay at the table. Prices are confirmed by the restaurant when you order.</p>
        {err && <div className="banner bad">{err}</div>}
        <button className="btn" disabled={busy || !items.length} onClick={place}>{busy ? 'Placing order…' : 'Place order'}</button>
      </aside>
    </div>)
}
