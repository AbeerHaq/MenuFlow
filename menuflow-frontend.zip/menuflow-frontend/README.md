# MenuFlow frontend — Safeer's part
Customer site (QR menu → cart → checkout), order tracking, owner Live Orders (Socket.io + sound), admin UI.

    cp .env.example .env && npm install && npm run dev

Routes: /r/:slug/t/:token · /order/:orderId · /dashboard/orders (owner) · /admin/login · /admin/restaurants · /admin/analytics
Abeer's owner layout should wrap /dashboard/orders; AuthContext + ProtectedRoute are shared (login() stores JWT as mf_token).

Assumed API shapes (confirm with Moiz/Umer):
- GET /public/menu/:slug/:token -> { restaurant:{name,logoUrl,address}, table:{tableNumber}, categories:[{_id,name,items?}], items?:[{_id,name,price,imageUrl,isAvailable,category}] }
- POST /public/orders {slug,token,customerName,note,items:[{menuItem,quantity}]} -> { orderId|_id, orderNumber, status }
- GET /public/orders/:id -> order (status, items[nameSnapshot,priceSnapshot,quantity], totalAmount, orderNumber)
- GET /owner/orders?status=PENDING,ACCEPTED,... ; PATCH /owner/orders/:id/status {status}
- Socket: handshake auth {token}; emit join:restaurant(restaurantId) / join:order(orderId); events order:new, order:updated (order object with _id)
- GET /admin/restaurants -> [{_id,name,owner:{name,email},status,createdAt,totalOrders,totalRevenue}]; PATCH /admin/restaurants/:id/status {status:'active'|'suspended'}; DELETE /admin/restaurants/:id
- GET /admin/analytics/revenue?from&to -> { totals:{revenue,orders,restaurants}, byDate:[{date,revenue}], byRestaurant:[{name,revenue}] }
